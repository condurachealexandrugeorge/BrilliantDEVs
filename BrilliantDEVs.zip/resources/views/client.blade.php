@extends('layouts.master')

@section('content')

    <p>Client</p>

@endsection