@extends('layouts.master')

@section('content')
<p>Manager</p>

@endsection