@extends('layouts.master')

@section('content')

    <p>Developer</p>

@endsection