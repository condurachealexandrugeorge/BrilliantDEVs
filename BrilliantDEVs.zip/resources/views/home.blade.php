@extends('layouts.master')

@section('style')
    <style>
        body {
            background-image: url("https://brilliantdevs.com/wp-content/uploads/2017/10/banner-02.jpg");
            background-repeat: no-repeat;
        }
    </style>

    @endsection

@section('content')


@endsection