<?php $__env->startSection('content'); ?>
    <div class="container">
    <table>
        <thead>
        <th>Nume</th>
        <th>Email</th>
        <th>Admin</th>
        <th>Manager</th>
        <th>Developer</th>
        <th>Client</th>
        <th></th>
        </thead>
        <tbody>
        <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <form action="<?php echo e(route('admin.assign')); ?>" method="post">
                    <td><?php echo e($user->name); ?></td>
                    <td><?php echo e($user->email); ?><input type="hidden" name="email" value="<?php echo e($user->email); ?>"></td>
                    <td><input type="checkbox" <?php echo e($user ->hasRole('Admin') ? 'checked' : ''); ?> name="role_admin"></td>
                    <td><input type="checkbox" <?php echo e($user ->hasRole('Manager') ? 'checked' : ''); ?> name="role_manager"></td>
                    <td><input type="checkbox" <?php echo e($user ->hasRole('Developer') ? 'checked' : ''); ?> name="role_developer"></td>
                    <td><input type="checkbox" <?php echo e($user ->hasRole('Client') ? 'checked' : ''); ?> name="role_client"></td>
                    <?php echo e(csrf_field()); ?>

                    <td><input type="submit" value="Asign Role"></td>
                </form>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
    </div>
    <?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>