<?php $__env->startSection('style'); ?>
    <style>
        body {
            background-image: url("https://brilliantdevs.com/wp-content/uploads/2017/10/banner-02.jpg");
            background-repeat: no-repeat;
        }
    </style>

    <?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>